import React from "react";
import Chatbot from "./chatbot";

function App() {
  return (
    <div>
      <Chatbot />
    </div>
  );
}

export default App;
